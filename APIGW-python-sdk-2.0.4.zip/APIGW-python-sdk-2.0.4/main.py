# coding=utf-8
import requests
from apig_sdk import signer

import os
import base64
import csv
import copy
import time
import json
import argparse
import itertools

import cv2 as cv
import mediapipe as mp
import numpy as np

from cvfpscalc import CvFpsCalc
from collections import Counter, deque


def get_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("--device", type=int, default=0)

    parser.add_argument("--width", help='cap width', type=int, default=960)

    parser.add_argument("--height", help='cap height', type=int, default=540)

    parser.add_argument('--configurations',
                        dest='configs',
                        default='./configurations.json',
                        help='Filepath of configuration file.')

    args = parser.parse_args()
    return args

def load_gesture_name(path):
    with open(path, encoding='utf-8-sig') as f:
        gesture_labels = csv.reader(f)
        gesture_labels = [row[0] for row in gesture_labels]

        return gesture_labels

def normalize_to_new_range(value, old_min=-1, old_max=1, new_min=0, new_max=1):
    # NewValue = (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
    return (((value - old_min) * (new_max - new_min)) / (old_max - old_min)) + new_min

def calc_landmark_list(image, landmarks, use_depth=False, calc_depth=False, depth_image=None, min_depth=0.6, max_depth=2.0, online=False, depth_range=19.9, online_crop_factor=0):
    image_width, image_height = image.shape[1], image.shape[0]
    new_landmarks = []

    for _, landmark in enumerate(landmarks.landmark):

        if not online_crop_factor:
            landmark_x = max(0, min(round(landmark.x * image_width), image_width-1))
            landmark_y = max(0, min(round(landmark.y * image_height), image_height-1))
        else:
            landmark_x = max(0, min(round(online_crop_factor * image_width + image_width * (1 - 2 * online_crop_factor) * landmark.x), image_width-1))
            landmark_y = max(0, min(round(online_crop_factor * image_height + image_height * (1 - 2 * online_crop_factor) * landmark.y), image_height-1))

        if use_depth:
            if calc_depth:
                if online:
                    landmark_depth = depth_image.get_distance(landmark_x, landmark_y)
                    landmark_z = landmark_depth/max_depth
                else:
                    landmark_depth = depth_image[landmark_x][landmark_y]*depth_range
                    landmark_z = landmark_depth/max_depth
            else:
                #landmark_z = landmark.z
                landmark_z = normalize_to_new_range(landmark.z)
            new_landmarks.append([landmark_x, landmark_y, landmark_z])
        else:
            new_landmarks.append([landmark_x, landmark_y])

    return new_landmarks

def calc_bounding_rect(image, landmarks):
    image_width, image_height = image.shape[1], image.shape[0]
    landmark_array = np.empty((0, 2), int)

    for _, landmark in enumerate(landmarks.landmark):
        landmark_x = min(int(landmark.x * image_width), image_width - 1)
        landmark_y = min(int(landmark.y * image_height), image_height - 1)

        landmark_point = [np.array((landmark_x, landmark_y))]

        landmark_array = np.append(landmark_array, landmark_point, axis=0)

    x, y, w, h = cv.boundingRect(landmark_array)

    return [x, y, x + w, y + h]

def pre_process_landmarks_history(image, landmarks_history, temporal_normalization=False, training=False, augmentation=[], prob_augmentation=[], use_depth=False):
    NLANDMARKS = 21
    image_width, image_height = image.shape[1], image.shape[0]

    temp_landmarks_history = copy.deepcopy(landmarks_history)

    if temporal_normalization:
        for index in range(len(temp_landmarks_history)):
            for i in range(NLANDMARKS):
                if index != 0:
                    temp_landmarks_history[index]['Left'][i][0] = (temp_landmarks_history[index]['Left'][i][0] - temp_landmarks_history[index-1]['Left'][i][0]) / image_width
                    temp_landmarks_history[index]['Left'][i][1] = (temp_landmarks_history[index]['Left'][i][1] - temp_landmarks_history[index-1]['Left'][i][1]) / image_height

                    temp_landmarks_history[index]['Right'][i][0] = (temp_landmarks_history[index]['Right'][i][0] - temp_landmarks_history[index-1]['Right'][i][0]) / image_width
                    temp_landmarks_history[index]['Right'][i][1] = (temp_landmarks_history[index]['Right'][i][1] - temp_landmarks_history[index-1]['Right'][i][1]) / image_height

                    # if use_depth:
                    temp_landmarks_history[index]['Left'][i][2] = temp_landmarks_history[index]['Left'][i][2] - temp_landmarks_history[index-1]['Left'][i][2]
                    temp_landmarks_history[index]['Right'][i][2] = temp_landmarks_history[index]['Right'][i][2] - temp_landmarks_history[index-1]['Right'][i][2]

                else:
                    temp_landmarks_history[index]['Left'][i][0] = temp_landmarks_history[index]['Left'][i][0] / image_width
                    temp_landmarks_history[index]['Left'][i][1] = temp_landmarks_history[index]['Left'][i][1] / image_height

                    temp_landmarks_history[index]['Right'][i][0] = temp_landmarks_history[index]['Right'][i][0] / image_width
                    temp_landmarks_history[index]['Right'][i][1] = temp_landmarks_history[index]['Right'][i][1] / image_height

    else:
        for index, _ in enumerate(temp_landmarks_history):
            for i in range(21):
                temp_landmarks_history[index]['Left'][i][0] = temp_landmarks_history[index]['Left'][i][0] / image_width
                temp_landmarks_history[index]['Left'][i][1] = temp_landmarks_history[index]['Left'][i][1] / image_height

                temp_landmarks_history[index]['Right'][i][0] = temp_landmarks_history[index]['Right'][i][0] / image_width
                temp_landmarks_history[index]['Right'][i][1] = temp_landmarks_history[index]['Right'][i][1] / image_height

    return temp_landmarks_history

def create_list_history(label, landmarks_history, max_num_hands=2):
    list_landmarks_history = []

    if label != None:
        list_landmarks_history.append(label)
    """
    for l in landmarks_history:
        
        left_hand_landmarks = l['Left']
        left_hand_landmarks = list(itertools.chain.from_iterable(left_hand_landmarks))
        if max_num_hands == 1 and all(item == 0 for item in left_hand_landmarks):
            pass
        else:
            list_landmarks_history.extend(left_hand_landmarks)

        right_hand_landmarks = l['Right']
        right_hand_landmarks = list(itertools.chain.from_iterable(right_hand_landmarks))
        if max_num_hands == 1 and all(item == 0 for item in right_hand_landmarks):
            pass
        else:
            list_landmarks_history.extend(right_hand_landmarks)
    """
    for l in landmarks_history:
        left_hand_landmarks = l['Left']
        left_hand_landmarks = list(itertools.chain.from_iterable(left_hand_landmarks))

        right_hand_landmarks = l['Right']
        right_hand_landmarks = list(itertools.chain.from_iterable(right_hand_landmarks))

        if max_num_hands == 2:
            list_landmarks_history.extend(left_hand_landmarks)
            list_landmarks_history.extend(right_hand_landmarks)
        else:
            empty_left = all(item == 0. for item in left_hand_landmarks)
            empty_right = all(item == 0. for item in right_hand_landmarks)

            if empty_left and empty_right:
                list_landmarks_history.extend(left_hand_landmarks)
                continue
            elif not empty_left:
                list_landmarks_history.extend(left_hand_landmarks)
                continue
            elif not empty_right:
                list_landmarks_history.extend(right_hand_landmarks)
                continue

    return list_landmarks_history

def draw_inference_time(image, inference_time):
    cv.putText(image, "Inference: " + str(inference_time) + " ms", (100, 15), cv.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 2, cv.LINE_AA)
    cv.putText(image, "Inference: " + str(inference_time) + " ms", (100, 15), cv.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv.LINE_AA)
    return image

def draw_bounding_rects(use_brect, image, brects):
    if use_brect:
        for brect in brects:
            cv.rectangle(image, (brect[0], brect[1]), (brect[2], brect[3]), (0, 0, 0), 1)

    return image

def draw_landmarks(image, landmarks_lists):
    for landmark_point in landmarks_lists:
        if len(landmark_point) > 0:
            cv.line(image, tuple(landmark_point[2][0:2]), tuple(landmark_point[3][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[2][0:2]), tuple(landmark_point[3][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[3][0:2]), tuple(landmark_point[4][0:2]), (0, 0, 0), 6)
            cv.line(image, tuple(landmark_point[3][0:2]), tuple(landmark_point[4][0:2]), (255, 255, 255), 1)

            cv.line(image, tuple(landmark_point[5][0:2]), tuple(landmark_point[6][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[5][0:2]), tuple(landmark_point[6][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[6][0:2]), tuple(landmark_point[7][0:2]), (0, 0, 0), 6)
            cv.line(image, tuple(landmark_point[6][0:2]), tuple(landmark_point[7][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[7][0:2]), tuple(landmark_point[8][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[7][0:2]), tuple(landmark_point[8][0:2]), (255, 255, 255), 1)

            cv.line(image, tuple(landmark_point[9][0:2]), tuple(landmark_point[10][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[9][0:2]), tuple(landmark_point[10][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[10][0:2]), tuple(landmark_point[11][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[10][0:2]), tuple(landmark_point[11][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[11][0:2]), tuple(landmark_point[12][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[11][0:2]), tuple(landmark_point[12][0:2]), (255, 255, 255), 1)

            cv.line(image, tuple(landmark_point[13][0:2]), tuple(landmark_point[14][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[13][0:2]), tuple(landmark_point[14][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[14][0:2]), tuple(landmark_point[15][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[14][0:2]), tuple(landmark_point[15][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[15][0:2]), tuple(landmark_point[16][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[15][0:2]), tuple(landmark_point[16][0:2]), (255, 255, 255), 1)

            cv.line(image, tuple(landmark_point[17][0:2]), tuple(landmark_point[18][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[17][0:2]), tuple(landmark_point[18][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[18][0:2]), tuple(landmark_point[19][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[18][0:2]), tuple(landmark_point[19][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[19][0:2]), tuple(landmark_point[20][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[19][0:2]), tuple(landmark_point[20][0:2]), (255, 255, 255), 1)

            cv.line(image, tuple(landmark_point[0][0:2]), tuple(landmark_point[1][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[0][0:2]), tuple(landmark_point[1][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[1][0:2]), tuple(landmark_point[2][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[1][0:2]), tuple(landmark_point[2][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[2][0:2]), tuple(landmark_point[5][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[2][0:2]), tuple(landmark_point[5][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[5][0:2]), tuple(landmark_point[9][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[5][0:2]), tuple(landmark_point[9][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[9][0:2]), tuple(landmark_point[13][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[9][0:2]), tuple(landmark_point[13][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[13][0:2]), tuple(landmark_point[17][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[13][0:2]), tuple(landmark_point[17][0:2]), (255, 255, 255), 1)
            cv.line(image, tuple(landmark_point[17][0:2]), tuple(landmark_point[0][0:2]), (0, 0, 0), 3)
            cv.line(image, tuple(landmark_point[17][0:2]), tuple(landmark_point[0][0:2]), (255, 255, 255), 1)

        for index, landmark in enumerate(landmark_point):
            if index == 0:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 1:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 2:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 3:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 4:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 4, (0, 0, 0), 1)
            if index == 5:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 6:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 7:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 8:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 4, (0, 0, 0), 1)
            if index == 9:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 10:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 11:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 12:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 4, (0, 0, 0), 1)
            if index == 13:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 14:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 15:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 16:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 4, (0, 0, 0), 1)
            if index == 17:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 18:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 19:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 2, (0, 0, 0), 1)
            if index == 20:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)
                cv.circle(image, (landmark[0], landmark[1]), 4, (0, 0, 0), 1)

    return image

def draw_info_text_brect(image, brects, handedness_list):

    i = 0
    for brect in brects:
        info_text = handedness_list[i].classification[0].label[0:]
        cv.rectangle(image, (brect[0], brect[1]), (brect[2], brect[1] - 20), (0, 0, 0), -1)
        cv.putText(image, info_text, (brect[0] + 5, brect[1] - 5), cv.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv.LINE_AA)

        i += 1

    return image

def draw_gesture_info(image, gesture_text):
    if gesture_text != "":
        cv.putText(image, "Gesture: " + gesture_text, (5, 30), cv.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 2, cv.LINE_AA)
        cv.putText(image, "Gesture: " + gesture_text, (5, 30), cv.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv.LINE_AA)

    return image

def draw_fps(image, fps):
    cv.putText(image, "FPS: " + str(fps), (5, 15), cv.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 2, cv.LINE_AA)
    cv.putText(image, "FPS: " + str(fps), (5, 15), cv.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv.LINE_AA)

    return image


if __name__ == '__main__':

    sig = signer.Signer()
    sig.Key = "KC3PGINR4UFQFN6IBF10"
    sig.Secret = "a6u67QebSy2xoQzaHIvHDinCZXj7SwxTu244kimr"

    r = signer.HttpRequest("POST", "https://infer-modelarts-euwest101.myhuaweicloud.com/v1/infers/fb8f2e56-2adc-4c22-a0a8-b1dd8163770d")
    r.headers = {"content-type": "application/json"}
    sig.Sign(r)


# Reading inputs parameters
    args = get_args()

    # Loading the configurations file.
    with open(args.configs, 'r') as f:
        configurations = json.load(f)

    # Loading some parameters from configuration file
    history_length = configurations['history_length']
    dimensions = configurations['dimensions']
    real_z = 'real_z' in configurations and configurations['real_z']

    ### Init VideoCapture
    cap_width = args.width
    cap_height = args.height
    cap_device = args.device

    cap = cv.VideoCapture(cap_device)
    cap.set(cv.CAP_PROP_FRAME_WIDTH, cap_width)
    cap.set(cv.CAP_PROP_FRAME_HEIGHT, cap_height)

    # Init Mediapipe
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=configurations['max_num_hands'],
        min_detection_confidence=configurations['min_detection_confidence'],
        min_tracking_confidence=configurations['min_tracking_confidence'])


    # Loading labels name
    gesture_labels = load_gesture_name('./labels.csv')

    # Index of No gesture.
    invalid_value = gesture_labels.index('No gesture')

    # Init Fps Calculator
    cvFpsCalc = CvFpsCalc(buffer_len=10)

    # Init Deques
    landmarks_history = deque(maxlen=history_length)
    gesture_history = deque(maxlen=configurations['number_of_gesture_detections'])

    # Init images
    image = None
    depth_image = None

    while True:
        fps = cvFpsCalc.get()

        # Read a frame from camera
        ret, image = cap.read()
        if not ret:
            break

        # Process the image
        image = cv.flip(image, 1)
        debug_image = copy.deepcopy(image)

        # Convert the image to RGB to make the prediction
        image = cv.cvtColor(image, cv.COLOR_BGR2RGB)

        # Run Mediapipe Inference
        image.flags.writeable = False
        results = hands.process(image)
        image.flags.writeable = True

        image_landmarks = {'Left': None, 'Right': None}
        gesture_id = invalid_value

        brects = []
        landmarks_lists = []
        handedness_list = []

        # If mediapipe find some hands
        if results.multi_hand_landmarks is not None:
            for hand_landmarks, handedness in zip(results.multi_hand_landmarks, results.multi_handedness):
                landmarks_list = calc_landmark_list(image, hand_landmarks, use_depth=dimensions==3, calc_depth=real_z, depth_image=depth_image, online=True)
                brect = calc_bounding_rect(debug_image, hand_landmarks)

                if handedness.classification[0].score > configurations['min_handedness_confidence'] and image_landmarks[handedness.classification[0].label]==None:
                    image_landmarks.update({handedness.classification[0].label: landmarks_list})

                    landmarks_lists.append(landmarks_list)
                    brects.append(brect)
                    handedness_list.append(handedness)

            if image_landmarks['Left'] == None:
                image_landmarks.update({'Left':[[0.0]*dimensions]*21})

            if image_landmarks['Right'] == None:
                image_landmarks.update({'Right':[[0.0]*dimensions]*21})

            if len(landmarks_history) == history_length and (landmarks_history[0]['Left'][0] != [0.0]*dimensions or landmarks_history[0]['Right'][0] != [0.0]*dimensions):
                # Preprocess the Landmarks list to make inference
                pre_processed_landmarks_history = pre_process_landmarks_history(image, landmarks_history, configurations['temporal_normalization'], training=False, use_depth=dimensions==3)
                input = create_list_history(None, pre_processed_landmarks_history, configurations['max_num_hands'])

                # Make inference
                ###################################################################################################################
                start_time = time.time()

                #base64_data = base64.b64encode(input).decode("utf-8")
                input = ''.join([str(f) for f in input]).encode('ascii')

                r.body = {"data": input}

                print(r.headers["X-Sdk-Date"])
                print(r.headers["Authorization"])

                print(r)

                resp = requests.request(r.method, r.scheme + "://" + r.host + r.uri, headers=r.headers, data=r.body)

                print(resp.status_code, resp.reason)
                print(resp.content)

                end_time = time.time()
                inference_time = end_time - start_time
                ###################################################################################################################

                # Draw some information on image
                debug_image = draw_inference_time(debug_image, round(inference_time, 7))

            # Draw some information on image
            debug_image = draw_bounding_rects(True, debug_image, brects)
            debug_image = draw_landmarks(debug_image, landmarks_lists)
            debug_image = draw_info_text_brect(debug_image, brects, handedness_list)

            if image_landmarks['Left']!=[[0.0]*dimensions]*21 or image_landmarks['Right']!=[[0.0]*dimensions]*21:
                landmarks_history.append(image_landmarks)
        else:
            try:
                landmarks_history.popleft()
            except:
                pass

        # Fill the Gesture Deque
        gesture_history.append(gesture_id)

        # Retrive the most common gesture
        most_common_gesture_id = Counter(gesture_history).most_common()[0][0]

        # Draw the gesture information on image
        debug_image = draw_gesture_info(debug_image, gesture_labels[most_common_gesture_id])

        # Draw the fps information on image
        debug_image = draw_fps(debug_image, fps)

        # Show Image
        cv.imshow('Hand Gesture Recognition', debug_image)

        # Save video
        # video_writer.write(debug_image)
        cv.waitKey(3)

    # Close VideoCapture
    cap.release()
    cv.destroyAllWindows()
