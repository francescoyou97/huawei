Here you can find the link to the drive folder created because the preprocessed datasets are too big to share on github

https://drive.google.com/drive/folders/1k9UaTeUrqp2Pf5BmtchZUfmduZILO_qe?usp=sharing