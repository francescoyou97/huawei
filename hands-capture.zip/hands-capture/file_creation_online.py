import argparse
import copy

import mediapipe as mp
from datetime import datetime

from utils import *


def main():
    # Get params
    args = get_args()
    
    show = args.show
    save_frames = args.save_frames
    
    cap_device = args.device
    cap_width = args.width
    cap_height = args.height
    cap_fps = args.fps
    
    min_detection_confidence = args.min_detection_confidence
    min_tracking_confidence = args.min_tracking_confidence
    min_handedness_confidence = args.min_handedness_confidence
    max_num_hands = args.max_num_hands
    
    dataset_path = args.dataset_path
    label = args.label
    
    num_frames_before_closing = args.num_frames_before_closing
    
    handedness = args.handedness
    
    ### VideoCapture init
    cap = cv.VideoCapture(cap_device)
    cap.set(cv.CAP_PROP_FRAME_WIDTH, cap_width)
    cap.set(cv.CAP_PROP_FRAME_HEIGHT, cap_height)
    cap.set(cv.CAP_PROP_FPS, cap_fps)

    ### Mediapipe init 
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=max_num_hands,
        min_detection_confidence=min_detection_confidence,
        min_tracking_confidence=min_tracking_confidence,
    )
    
    # Some useful variables
    null_counter  = 0 # Used to stop when a gesture is closed
    first_time = True
    frames_counter = 0
    
    # Fps calculator
    cvFpsCalc = CvFpsCalc(buffer_len=10)
    
    # Data structure
    data_deque = deque()
    
    if save_frames:
        video_writer = cv.VideoWriter('./video_' + str(datetime.now().strftime("%H%M%S")) + '.mp4', cv.VideoWriter_fourcc('m', 'p', '4', 'v'), 25, (cap_width, cap_height), True)
    
    # While loop to caputure gesture
    while True:
        
        # Get the framerate
        fps = cvFpsCalc.get()
        
        # Get a frame
        ret, image = cap.read()
        
        if ret:
            image = cv.flip(image, 1)
            debug_image = copy.deepcopy(image)
            image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
            
            image.flags.writeable = False
            results = hands.process(image)
            image.flags.writeable = True
            
            if results.multi_hand_landmarks is not None:
                update_data_deque(data_deque, results, min_handedness_confidence, handedness, max_num_hands)
                
                null_counter = 0
                if first_time:
                    first_time = False
                
                if show:    
                    landmark_lists = []            
                    for hand_landmarks in results.multi_hand_landmarks:
                        landmark_list = calc_landmark_list(image, hand_landmarks)
                        landmark_lists.append(landmark_list)                    
                    debug_image = draw_landmarks(debug_image, landmark_lists)    
            else:
                null_counter += 1
                if null_counter >= num_frames_before_closing and not first_time:
                    print(f"Closing capture after {num_frames_before_closing} empty frames.")
                    break
            
            if show:       
                debug_image = draw_info(debug_image, fps)
                cv.imshow('Mediapipe', debug_image)
                cv.waitKey(1)  
        else:
            break
        
        if save_frames:
            video_writer.write(debug_image)
            frames_counter += 1
            write_frames(debug_image, frames_counter)
    
    print(str(len(data_deque)))
    if len(data_deque) != 0:
        # Create dataset, label and sample folder
        sample_folder_path = create_folders(dataset_path, label)
        
        # Write the data structure
        write_json_data(data_deque, sample_folder_path)
    
    cv.destroyAllWindows()
    cap.release()
    
    if save_frames:
        video_writer.release()
    
    

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", help='cap device to use', type=int, default=2)
    parser.add_argument("--width", help='cap width', type=int, default=640)
    parser.add_argument("--fps", help='cap fps', type=int, default=60)
    parser.add_argument("--height", help='cap height', type=int, default=480)
    parser.add_argument("--dataset_path", help='dataset folder to save pose files', type=str, default="./dataset/")
    parser.add_argument("--label", help='label index', type=int, default=0)
    parser.add_argument("--show", help='to show captured frames', default=False, action='store_true')
    parser.add_argument("--save_frames", help='to save processed frames', default=False, action='store_true')
    parser.add_argument("--num_frames_before_closing", help='number of empty frames before closing app', type=int, default=35)
    parser.add_argument("--min_detection_confidence", help='Mediapipe params', type=float, default=0.75)
    parser.add_argument("--min_tracking_confidence", help='Mediapipe params', type=float, default=0.70)
    parser.add_argument("--min_handedness_confidence", help='Mediapipe params',type=float, default=0.90)
    parser.add_argument("--max_num_hands", help='Mediapipe params', type=int, default=1)
    parser.add_argument("--handedness", help="Left or Right, used only with one hand", type=str, default="")
    args = parser.parse_args()
    return args


if __name__ == "__main__":        
    main()
