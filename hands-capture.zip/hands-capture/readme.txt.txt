folder 1 represents all the samples of landmarks captured for a gesture: 10 different captures 
were made for this gesture; therefore, it is possible to notice 10 subdirectories, 
each of which contains a Pose.json file, with the positions of the hand joints over time.