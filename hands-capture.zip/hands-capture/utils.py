import os
import time
from collections import deque

import cv2 as cv
import numpy as np
import ujson as json

WRIST = 0
THUMB_CMC = 1
THUMB_MCP = 2
THUMB_IP = 3
THUMB_TIP = 4
INDEX_FINGER_MCP = 5
INDEX_FINGER_PIP = 6
INDEX_FINGER_DIP = 7
INDEX_FINGER_TIP = 8
MIDDLE_FINGER_MCP = 9
MIDDLE_FINGER_PIP = 10
MIDDLE_FINGER_DIP = 11
MIDDLE_FINGER_TIP = 12
RING_FINGER_MCP = 13
RING_FINGER_PIP = 14
RING_FINGER_DIP = 15
RING_FINGER_TIP = 16
PINKY_MCP = 17
PINKY_PIP = 18
PINKY_DIP = 19
PINKY_TIP = 20

landmarks_dict = {
    WRIST:"WRIST",
    THUMB_CMC:"THUMB_CMC",
    THUMB_MCP:"THUMB_MCP",
    THUMB_IP:"THUMB_IP",
    THUMB_TIP:"THUMB_TIP",
    INDEX_FINGER_MCP:"INDEX_FINGER_MCP",
    INDEX_FINGER_PIP:"INDEX_FINGER_PIP",
    INDEX_FINGER_DIP:"INDEX_FINGER_DIP",
    INDEX_FINGER_TIP:"INDEX_FINGER_TIP",
    MIDDLE_FINGER_MCP:"MIDDLE_FINGER_MCP",
    MIDDLE_FINGER_PIP:"MIDDLE_FINGER_PIP",
    MIDDLE_FINGER_DIP:"MIDDLE_FINGER_DIP",
    MIDDLE_FINGER_TIP:"MIDDLE_FINGER_TIP",
    RING_FINGER_MCP:"RING_FINGER_MCP",
    RING_FINGER_PIP:"RING_FINGER_PIP",
    RING_FINGER_DIP:"RING_FINGER_DIP",
    RING_FINGER_TIP:"RING_FINGER_TIP",
    PINKY_MCP:"PINKY_MCP",
    PINKY_PIP:"PINKY_PIP",
    PINKY_DIP:"PINKY_DIP",
    PINKY_TIP:"PINKY_TIP"        
}


class CvFpsCalc(object):
    def __init__(self, buffer_len=1):
        self._start_tick = cv.getTickCount()
        self._freq = 1000.0 / cv.getTickFrequency()
        self._difftimes = deque(maxlen=buffer_len)

    def get(self):
        current_tick = cv.getTickCount()
        different_time = (current_tick - self._start_tick) * self._freq
        self._start_tick = current_tick

        self._difftimes.append(different_time)

        fps = 1000.0 / (sum(self._difftimes) / len(self._difftimes))
        fps_rounded = round(fps, 2)

        return fps_rounded


def calc_landmark_list(image, landmarks):
    image_width, image_height = image.shape[1], image.shape[0]

    landmark_point = []

    for _, landmark in enumerate(landmarks.landmark):
        landmark_x = min(int(landmark.x * image_width), image_width - 1)
        landmark_y = min(int(landmark.y * image_height), image_height - 1)
        landmark_z = landmark.z

        landmark_point.append([landmark_x, landmark_y, landmark_z])

    return landmark_point


def calc_bounding_rect(image, landmarks):
    image_width, image_height = image.shape[1], image.shape[0]

    landmark_array = np.empty((0, 2), int)

    for _, landmark in enumerate(landmarks.landmark):
        landmark_x = min(int(landmark.x * image_width), image_width - 1)
        landmark_y = min(int(landmark.y * image_height), image_height - 1)

        landmark_point = [np.array((landmark_x, landmark_y))]

        landmark_array = np.append(landmark_array, landmark_point, axis=0)

    x, y, w, h = cv.boundingRect(landmark_array)

    return [x, y, x + w, y + h]


def draw_bounding_rects(use_brect, image, brects):
    if use_brect:
        for brect in brects: 
            cv.rectangle(image, (brect[0], brect[1]), (brect[2], brect[3]), (0, 0, 0), 1)
            
    return image


def draw_landmarks(image, landmark_point_list):
    
    for landmark_point in landmark_point_list:

        if len(landmark_point) > 0:
            cv.line(image, tuple(landmark_point[2][0:2]), tuple(landmark_point[3][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[3][0:2]), tuple(landmark_point[4][0:2]), (255, 255, 255), 2)

            cv.line(image, tuple(landmark_point[5][0:2]), tuple(landmark_point[6][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[6][0:2]), tuple(landmark_point[7][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[7][0:2]), tuple(landmark_point[8][0:2]), (255, 255, 255), 2)

            cv.line(image, tuple(landmark_point[9][0:2]), tuple(landmark_point[10][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[10][0:2]), tuple(landmark_point[11][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[11][0:2]), tuple(landmark_point[12][0:2]), (255, 255, 255), 2)

            cv.line(image, tuple(landmark_point[13][0:2]), tuple(landmark_point[14][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[14][0:2]), tuple(landmark_point[15][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[15][0:2]), tuple(landmark_point[16][0:2]), (255, 255, 255), 2)

            cv.line(image, tuple(landmark_point[17][0:2]), tuple(landmark_point[18][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[18][0:2]), tuple(landmark_point[19][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[19][0:2]), tuple(landmark_point[20][0:2]), (255, 255, 255), 2)

            cv.line(image, tuple(landmark_point[0][0:2]), tuple(landmark_point[1][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[1][0:2]), tuple(landmark_point[2][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[2][0:2]), tuple(landmark_point[5][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[5][0:2]), tuple(landmark_point[9][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[9][0:2]), tuple(landmark_point[13][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[13][0:2]), tuple(landmark_point[17][0:2]), (255, 255, 255), 2)
            cv.line(image, tuple(landmark_point[17][0:2]), tuple(landmark_point[0][0:2]), (255, 255, 255), 2)

        for index, landmark in enumerate(landmark_point):
            if index == 0:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 1:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 2:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 3:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 4:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)
            if index == 5:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 6:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 7:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 8:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)
            if index == 9:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 10:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 11:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 12:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)
            if index == 13:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 14:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 15:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 16:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)
            if index == 17:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 18:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 19:
                cv.circle(image, (landmark[0], landmark[1]), 2, (255, 255, 255), -1)
            if index == 20:
                cv.circle(image, (landmark[0], landmark[1]), 4, (255, 255, 255), -1)

    return image


def draw_info_text_brect(image, brects, handedness_list):
    
    i = 0
    for brect in brects:
        cv.rectangle(image, (brect[0], brect[1]), (brect[2], brect[1] - 22), (0, 0, 0), -1)

        info_text = handedness_list[i].classification[0].label[0:]
        i+=1
        
        cv.putText(image, info_text, (brect[0] + 5, brect[1] - 4), cv.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv.LINE_AA)
        
    return image
    
    
def draw_info(image, fps):
    cv.putText(image, "FPS:" + str(fps), (5, 15), cv.FONT_HERSHEY_SIMPLEX,
               0.4, (0, 0, 0), 2, cv.LINE_AA)
    cv.putText(image, "FPS:" + str(fps), (5, 15), cv.FONT_HERSHEY_SIMPLEX,
               0.4, (255, 255, 255), 1, cv.LINE_AA)
    
    return image


def update_data_deque(data_deque, results, min_handedness_confidence, handedness_selected, max_num_hands):
    new_frame = {}          
    new_frame.update({"FrameNumber": len(data_deque)})
    
    landmarks_node = {}
    for hand_landmarks, handedness in zip(results.multi_hand_landmarks, results.multi_handedness):
        '''
        if handedness.classification[0].score > min_handedness_confidence:
            if max_num_hands == 1 and handedness_selected == handedness.classification[0].label:
                handedness = handedness_selected
                handedness_check = True
            if max_num_hands > 1 or handedness_selected == "":
                handedness = handedness.classification[0].label
                handedness_check = True
        else:
            print("Handedness threshold not exceeded.")
        '''

        handedness_check = False
        if max_num_hands == 1 and handedness.classification[0].label != "":
            handedness = handedness_selected
            handedness_check = True
        else:
            if handedness.classification[0].score > min_handedness_confidence:
                handedness = handedness.classification[0].label
                handedness_check = True
        
        print(handedness_check)
        
        if handedness_check == True:            
            for index, landmark in enumerate(hand_landmarks.landmark): 
                landmark_node = {}
                landmark_node.update({"Name": landmarks_dict[index]})
                
                position = {}
                position.update({"x": landmark.x})
                position.update({"y": landmark.y})
                position.update({"z": landmark.z})
                
                landmark_node.update({"Position":position})
                
                if index!=THUMB_TIP and index!=INDEX_FINGER_TIP and index!=MIDDLE_FINGER_TIP and index!=RING_FINGER_TIP and index!=PINKY_TIP:
                    landmark_node.update({"Children":[]})
                                        
                landmarks_node.update({index:landmark_node})
                                
            root = landmarks_node[WRIST]
            
            root["Children"].append(landmarks_node[THUMB_CMC])
            root["Children"].append(landmarks_node[INDEX_FINGER_MCP])
            root["Children"].append(landmarks_node[MIDDLE_FINGER_MCP])
            root["Children"].append(landmarks_node[RING_FINGER_MCP])
            root["Children"].append(landmarks_node[PINKY_MCP])
            
            root["Children"][0]["Children"].append(landmarks_node[THUMB_MCP])
            root["Children"][1]["Children"].append(landmarks_node[INDEX_FINGER_PIP])
            root["Children"][2]["Children"].append(landmarks_node[MIDDLE_FINGER_PIP])
            root["Children"][3]["Children"].append(landmarks_node[RING_FINGER_PIP])
            root["Children"][4]["Children"].append(landmarks_node[PINKY_PIP])
            
            root["Children"][0]["Children"][0]["Children"].append(landmarks_node[THUMB_IP])       
            root["Children"][1]["Children"][0]["Children"].append(landmarks_node[INDEX_FINGER_DIP])    
            root["Children"][2]["Children"][0]["Children"].append(landmarks_node[MIDDLE_FINGER_DIP])
            root["Children"][3]["Children"][0]["Children"].append(landmarks_node[RING_FINGER_DIP])
            root["Children"][4]["Children"][0]["Children"].append(landmarks_node[PINKY_DIP])
                        
            root["Children"][0]["Children"][0]["Children"][0]["Children"].append(landmarks_node[THUMB_TIP])
            root["Children"][1]["Children"][0]["Children"][0]["Children"].append(landmarks_node[INDEX_FINGER_TIP])
            root["Children"][2]["Children"][0]["Children"][0]["Children"].append(landmarks_node[MIDDLE_FINGER_TIP])
            root["Children"][3]["Children"][0]["Children"][0]["Children"].append(landmarks_node[RING_FINGER_TIP])
            root["Children"][4]["Children"][0]["Children"][0]["Children"].append(landmarks_node[PINKY_TIP])
            
            new_frame.update({"Root_" + handedness : root})
        else:
            print("Skip due to handedness.")
    
    if "Root_Left" in new_frame or "Root_Right" in new_frame:   
        data_deque.append(new_frame)


def write_json_data(data_deque, path="./"):
    data = {'Frames': list(data_deque)}
    
    with open(os.path.join(path, 'Pose.json'), 'w') as json_file:
        json.dump(data, json_file, indent=4)
        
    time.sleep(5)
    

def write_frames(image, id, path="./frames"):
    if not os.path.exists(path):
        os.mkdir(path)
    
    if id == 0:
        import glob
        files = glob.glob(f'{path}/*')
        for f in files:
            os.remove(f)
    
    cv.imwrite(f'{path}/image_{id}.png', image)


def create_folders(dataset_path, label):
        # Dataset folder
    if not os.path.exists(dataset_path):
        print("Dataset folder exists")
        os.mkdir(dataset_path)
    
    # Label folder
    label_path = dataset_path + f"/{label}"
    if not os.path.exists(label_path):
        print("Label Path exists")
        os.mkdir(label_path)
    
    # Samples folder
    samples_folders = os.listdir(label_path)
    if len(samples_folders) > 0:
        sample_index = int(samples_folders[-1]) + 1
    else:
        sample_index = 0
    
    sample_folder_path = label_path + f"/{sample_index}"
    os.mkdir(sample_folder_path)
    
    return sample_folder_path
