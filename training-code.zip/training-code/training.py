import os
import argparse
import json
import csv
import math

os.system('pip3 install opencv-python')
os.system('pip install mediapipe')
os.system('pip install -U --force-reinstall keras')
os.system('pip install -U --force-reinstall tensorflow==2.5.0')
os.system('pip install -U --force-reinstall numpy==1.18.5')


import numpy as np
import tensorflow as tf

from tensorflow.keras.optimizers import Adam, RMSprop
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
############################################################################################################################
# CONSTANT
NLANDMARKS = 21

############################################################################################################################
# DATA FUNCTIONS
def load_gesture_name(path):
    with open(path,
            encoding='utf-8-sig') as f:
        gesture_labels = csv.reader(f)
        gesture_labels = [
            row[0] for row in gesture_labels
        ]
    
    return gesture_labels

############################################################################################################################
### FUNCTION FOR DATASET SAMPLING

def dataset_upsampling(X, y):
    """Upsamples the dataset so that you have the same number of samples for each class.

    Args:
        X (float numpy array): Samples
        y (int numpy array): Labels

    Returns:
        (float numpy array, int numpy array): The upsampled dataset.
    """
    
    print("Upsampling dataset")
        
    labels = np.unique(y)
    
    max_number_of_samples_per_class = 0
    for label in labels:
        y_selected = np.where(y==label)[0]
        
        if len(y_selected) > max_number_of_samples_per_class:
            max_number_of_samples_per_class = len(y_selected)
        
    print(f"max_number_of_samples_per_class: {max_number_of_samples_per_class}")
        
    res_X = []
    res_y = []
    
    for label in labels:
        y_selected = np.where(y==label)[0]
        choices = np.random.choice(y_selected, max_number_of_samples_per_class)
        
        res_X_selected = X[choices]
        res_y_selected = y[choices]
        
        res_X.append(res_X_selected)
        res_y.append(res_y_selected)
        
    res_X = np.concatenate(res_X, axis=0)
    res_y = np.concatenate(res_y, axis=0)
    
    order = np.arange(len(res_y))
    np.random.shuffle(order)
    
    res_X = res_X[order]
    res_y = res_y[order]
    
    print(f"Balanced dataset shape: {res_y.shape}")
    return res_X, res_y 


def dataset_downsampling(X, y):
    """Downsamples the dataset so that you have the same number of samples for each class.

    Args:
        X (float numpy array): Samples
        y (int numpy array): Labels

    Returns:
        (float numpy array, int numpy array): The downsampled dataset.
    """
    
    print("Downsampling dataset")
    
    labels = np.unique(y)
    
    min_number_of_samples_per_class = 0
    for label in labels:
        y_selected = np.where(y==label)[0]
        
        if len(y_selected) < min_number_of_samples_per_class:
            min_number_of_samples_per_class = len(y_selected)
        
    print(f"min_number_of_samples_per_class: {min_number_of_samples_per_class}")
        
    res_X = []
    res_y = []
    
    for label in labels:
        y_selected = np.where(y==label)[0]
        choices = np.random.choice(y_selected, min_number_of_samples_per_class)
        
        res_X_selected = X[choices]
        res_y_selected = y[choices]
        
        res_X.append(res_X_selected)
        res_y.append(res_y_selected)
        
    res_X = np.concatenate(res_X, axis=0)
    res_y = np.concatenate(res_y, axis=0)
    
    order = np.arange(len(res_y))
    np.random.shuffle(order)
    
    res_X = res_X[order]
    res_y = res_y[order]
    
    print(f"Balanced dataset shape: {res_y.shape}")
    return res_X, res_y

############################################################################################################################
### TRAINING
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Train Hand Gestures", formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    # Add parameters.
    parser.add_argument('--train_url', type=str, help='the path model saved')
    parser.add_argument('--training_set_url', type=str, help='the training data')
    parser.add_argument('--validation_set_url', type=str, help='the validation data')
    parser.add_argument('--test_set_url', type=str, help='the test data')
    parser.add_argument('--labels_url', type=str, help='labels')
    parser.add_argument('--configs', dest='configs', default='./configs.json', help='Filepath of configurations file')
    
    # Parse the parameters.
    args, unknown = parser.parse_known_args()
    
    # Loading the configurations file. 
    with open(args.configs,'r') as f:
        configurations = json.load(f)

    # Setting random seed
    tf.random.set_seed(configurations['seed'])
    np.random.seed(configurations['seed'])
    
    ############################################################################################################################
    ### LABELS
    # Loading labels name
    print("\nLoading labels")
    labels_path = args.labels_url
    gesture_labels = load_gesture_name(labels_path)
    
    ############################################################################################################################
    ### DATASET LOADING
    print("\nLoading datasets")
    training = args.training_set_url
    validation = args.validation_set_url
    test = args.test_set_url
        
    X_train = np.loadtxt(training, delimiter=',', dtype='float32', usecols=list(range(1, (configurations['history_length'] * configurations['dimensions'] * configurations['max_num_hands'] * NLANDMARKS) + 1)))
    print(f"X_train loaded! {len(X_train)} samples")

    y_train = np.loadtxt(training, delimiter=',', dtype='int32', usecols=(0))
    print(f"y_train loaded")

    X_val = np.loadtxt(validation, delimiter=',', dtype='float32', usecols=list(range(1, (configurations['history_length'] * configurations['dimensions'] * configurations['max_num_hands'] * NLANDMARKS) + 1)))
    print(f"\nX_val loaded! {len(X_val)} samples")

    y_val = np.loadtxt(validation, delimiter=',', dtype='int32', usecols=(0))
    print(f"y_val loaded")
 
    X_test = np.loadtxt(test, delimiter=',', dtype='float32', usecols=list(range(1, (configurations['history_length'] * configurations['dimensions'] * configurations['max_num_hands'] * NLANDMARKS) + 1)))
    print(f"\nX_test loaded! {len(X_test)} samples")

    y_test = np.loadtxt(test, delimiter=',', dtype='int32', usecols=(0))
    print(f"y_test loaded\n")
 
    # Dataset balancing
    if configurations['upsampling']:
        X_train, y_train = dataset_upsampling(X_train, y_train)

    if configurations['downsampling']:
        X_train, y_train = dataset_downsampling(X_train, y_train)

    class_weight = None    
    batch_size = configurations['batch_size']
    
    n_samples = len(X_train)
    n_batches = n_samples // batch_size
    n_samples_new = n_batches * batch_size
    num_missing_samples = batch_size - n_samples_new % batch_size
    X_train = X_train[:n_samples_new]
    y_train = y_train[:n_samples_new]
    
    n_samples = len(X_val)
    n_batches = n_samples // batch_size
    n_samples_new = n_batches * batch_size
    num_missing_samples = batch_size - n_samples_new % batch_size
    X_val = X_val[:n_samples_new]
    y_val = y_val[:n_samples_new]
   
    n_samples = len(X_test)
    n_batches = n_samples // batch_size
    n_samples_new = n_batches * batch_size
    num_missing_samples = batch_size - n_samples_new % batch_size
    X_test = X_test[:n_samples_new]
    y_test = y_test[:n_samples_new]
    
    steps_per_epoch = round(len(X_train)/configurations['batch_size'])
    validation_steps = round(len(X_val)/configurations['batch_size'])
    
    ############################################################################################################################
    ### MODEL DEFIITION
    if 'dataset' in configurations and configurations['dataset'] == 'synthetic':
        first_recurrent_dropout = configurations['first_dropout']
        second_recurrent_dropout = configurations['second_dropout']
    else:
        first_recurrent_dropout = 0.
        second_recurrent_dropout = 0.
            
    # Model definition
    inputs = tf.keras.Input(batch_input_shape=(configurations['batch_size'], configurations['history_length'] * configurations['dimensions'] * configurations['max_num_hands'] * NLANDMARKS))
    r = tf.keras.layers.Reshape((configurations['history_length'], configurations['dimensions'] * configurations['max_num_hands'] * NLANDMARKS))(inputs)
    lstm_cell = tf.keras.layers.LSTMCell(configurations['n_units_first_layer'], recurrent_dropout=first_recurrent_dropout)
    l1 = tf.keras.layers.RNN(lstm_cell, return_sequences=True, unroll=True)(r, initial_state=lstm_cell.get_initial_state(batch_size=configurations['batch_size'], dtype=tf.float32))
    d1 = tf.keras.layers.Dropout(configurations['first_dropout'], seed=configurations['seed'])(l1)
    lstm_cell = tf.keras.layers.LSTMCell(configurations['n_units_second_layer'], recurrent_dropout=second_recurrent_dropout)
    l2 = tf.keras.layers.RNN(lstm_cell, unroll=True)(d1, initial_state=lstm_cell.get_initial_state(batch_size=configurations['batch_size'], dtype=tf.float32))
    d2 = tf.keras.layers.Dropout(configurations['second_dropout'], seed=configurations['seed'])(l2)
    outputs = tf.keras.layers.Dense(configurations['number_of_classes'], activation='softmax')(d2)
    model = tf.keras.Model(inputs=inputs, outputs=outputs)
        
    # Model summary
    model.summary()

    # Optimizer
    if configurations['optimizer'] == 'adam':
        optimizer = Adam(learning_rate=configurations['learning_rate'])
    elif configurations['optimizer'] == 'rmsprop':
        optimizer = RMSprop(learning_rate=configurations['learning_rate'], momentum=0.9) # clipnorm=1.0

    # Model Compile
    model.compile(
        optimizer=optimizer,
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy'])
    
    # Callbacks
    callbacks = [                                                
        EarlyStopping(min_delta=0.0000000001,
                            patience=configurations['early_stopping_patience'],
                            restore_best_weights=True,
                            monitor='val_loss',
                            mode='min',
                            verbose=1),                                   
        ReduceLROnPlateau(factor=0.1,
                            min_delta=0.0000001, 
                            patience=configurations['reduce_lr_patience'], 
                            verbose=1,
                            monitor='val_loss',
                            mode='min')]
        
    # Model training    
    print("\nStart training")
    history = model.fit(
                X_train,
                y_train,
                epochs=configurations['epochs'],
                batch_size=configurations['batch_size'],
                validation_data=(X_val, y_val),
                steps_per_epoch=steps_per_epoch,
                validation_steps=validation_steps,
                callbacks=callbacks,
                shuffle=configurations['shuffle'],
                class_weight=class_weight)
    
    # Model evaluation
    print("\nBaseline model evaluation!")
    _, baseline_model_accuracy = model.evaluate(X_test, y_test, batch_size=configurations['batch_size'])
        
    # Save the model 
    model_save_path = args.train_url[:-1]
    tf.saved_model.save(model, model_save_path, signatures=None, options=None)
    
    # Configuration file
    configurations_save_path = os.path.join(model_save_path, "configurations.json") 
    with open(configurations_save_path, 'w') as fp:
        json.dump(configurations, fp, indent=2)    