import os
import json
import logging
import threading

import numpy as np
import tensorflow as tf

from model_service.tfserving_model_service import TfServingBaseService


logger = logging.getLogger()
logger.setLevel(logging.INFO)


class HandGesturesService(TfServingBaseService):
    
    def __init__(self, model_name, model_path):
        self.model_name = model_name
        self.model_path = model_path
        
        print(self.model_path)   
        print(os.listdir(self.model_path))    
        
        self.model = None
        self.predict = None
        self.configurations = self.load_configurations(os.path.join(self.model_path, 'configurations.json'))
        
        self.history_length = self.configurations['history_length']
        self.dimensions = self.configurations['dimensions']
        self.real_z = 'real_z' in self.configurations and self.configurations['real_z']
        
        thread = threading.Thread(target=self.load_model)
        thread.start()
      
    def load_configurations(self, path):
        with open(path,'r') as f:
            return json.load(f)
    
    
    def load_model(self):
        # Load the model in saved_model format.
        self.model = tf.saved_model.load(self.model_path)

        signature_defs = self.model.signatures.keys()

        signature = []
        # only one signature allowed
        for signature_def in signature_defs:
            signature.append(signature_def)

        if len(signature) == 1:
            model_signature = signature[0]
        else:
            logging.warning("signatures more than one, use serving_default signature from %s", signature)
            model_signature = tf.saved_model.DEFAULT_SERVING_SIGNATURE_DEF_KEY

    
        
    def _preprocess(self, data):        
        input = []
        for v in data.values():
            raw = []
            for e in v:
                raw.append(e)
            
            input.append(raw)
            
        input = tf.convert_to_tensor(input, dtype=tf.dtypes.float32)
        return input        


    def _inference(self, data):

        # result = self.predict(data)
        result = self.model.predict(data, batch_size=1)
        gesture_id = np.argmax(np.squeeze(result))
        
        if np.squeeze(result)[gesture_id] < self.score_th:
            gesture_id = self.invalid_value
            
        return gesture_id
    
    
    def _postprocess(self, data):
        return data["output"].numpy()
        
            
    